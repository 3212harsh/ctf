let mongoose = require('mongoose');

let modschema = mongoose.Schema({
    modulename : {
        type : String,
        required : true,
    },
    image : String,
    catagory : {
        type : Array,
        default : [],
        required : true,
    },
    difficulty : String,
    section:[{
        sectionname:String,
        data:String,
        questions : [],
        answers : [],
        done:{
            type:Boolean,
            default:false,
        },
    }],
});
module.exports = mongoose.model('modules',modschema);