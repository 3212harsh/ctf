let mongoose = require('mongoose');
let roomschema = mongoose.Schema({
    name:String,
    type:String,
    createdby:String,
})

module.exports = mongoose.model('rooms',roomschema);