let mongoose = require('mongoose');
let mentorschema = mongoose.Schema({
    image:String,
    name:{
        type:String,
    },
    prof:String,
    discription:{
        type:String,
    },
    clients:String,
    rating:String,
    price:String

});

module.exports = mongoose.model('mentor',mentorschema);