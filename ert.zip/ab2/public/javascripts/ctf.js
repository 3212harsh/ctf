const { json, response } = require("express");
const { post } = require("../../routes");

function addinarray(a){
    let array = document.getElementById('array').innerHTML.split(',');
    if (array[0] == "")
    {
        array[0] = a;
    }
    else{
        array.push(a);
    }
    let uparray = "";
    array.forEach((e)=>{
        uparray+=e+","
    })
    uparray=uparray.slice(0,-1);
    document.getElementById('array').innerHTML = uparray
    // console.log(uparray);

}

function create(){
    let array = document.getElementById('array').innerHTML.split(',');
    let a = document.getElementById('ctfname');
    let b = a.value;
    console.log(b);
    let data = {
        name:b,
        challenges:array
    }
    fetch('http://localhost:80/createctf',{
        method:'POST',
        headers:{
            'Content-type' : 'application/json'
        },
        body : JSON.stringify(data)
        
    })
    .then((res)=>{
        return res.json();
    })
    .then((response)=>{
        console.log(response);
        let btn = document.getElementById('ctfcreatebtn');
        btn.style.display = 'none';
        let ttl = document.getElementById('total');
        ttl.style.top = '88px'
        document.getElementById('ctf_main').innerHTML=`<div id = 'create_mes'> <div id='create_head'><h1>Your CTF is Hosted successfully</h1></div><div id='create_link'><a href='${response.cat}' target='_blank'>${response.cat}</a></div> </div>`;
    })
    .catch((err)=>{console.log(err);})
}

function delinarray(a){
    let array = document.getElementById('array').innerHTML.split(',');
    const indexToDelete = array.indexOf(a);
    if (indexToDelete !== -1) {
        array.splice(indexToDelete, 1);
    }
    let uparray = "";
    array.forEach((e)=>{
        uparray+=e+","
    })
    uparray=uparray.slice(0,-1);
    document.getElementById('array').innerHTML = uparray
    // console.log(uparray);
      
      
}

function select(task) {
    if (task && task.classList) {
        task.classList.toggle("selected");
        let s = task.querySelector("#select_btn");
        let d = task.querySelector('h3').innerHTML
        s.classList.toggle("selected_i");
        if (task.classList.contains("selected")) {
            let total = document.getElementById('total').innerHTML;
            let t = parseInt(total);
            t++;
            document.getElementById('total').innerHTML = t;
            addinarray(d);
        } else {
            let total = document.getElementById('total').innerHTML;
            let t = parseInt(total);
            t--;
            document.getElementById('total').innerHTML = t;
            delinarray(d);
        }
    } else {
        console.error("Invalid task element:", task);
    }

}

function showchallenge(data){
    let array = document.getElementById('array').innerHTML.split(',');
    let container = document.getElementById('ctf_showchal');
    container.innerHTML="";
    data.forEach(element => {
        let d = container.innerHTML;
        // for(i=0;i<array.length;i++)
        // {
        //     if (array[i]==element.name){
        //         container.innerHTML=d+`<div class='ctf_item' onclick='select(this)'><h3>${element.name}</h3> <div id='select_btn'><i class="fa-solid fa-check"></i></div></div>`;
        //         this.classList
        //     }
        // }
        container.innerHTML=d+`<div class='ctf_item' onclick='select(this)'><h3>${element.name}</h3> <div id='select_btn'><i class="fa-solid fa-check"></i></div></div>`;
    });
};

function search(a){
    let data = {
        type:a
    };
    fetch('/showchallenge',{
        method:'POST',
        headers:{
            'Content-type' : 'application/json'
        },
        body : JSON.stringify(data)
    })
    .then((response)=>{
        return response.json();
    })
    .then((data)=>{
        showchallenge(data);
    })
    .catch("failed");
}