function resume(a){
    console.log(a);
}